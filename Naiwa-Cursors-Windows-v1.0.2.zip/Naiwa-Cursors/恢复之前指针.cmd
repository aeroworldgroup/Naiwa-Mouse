@echo off
setlocal
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Setup.ps1" -Restore
set "naiwa_result=%errorlevel%"
echo.
pause
exit /b %naiwa_result%
