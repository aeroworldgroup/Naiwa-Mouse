﻿[CmdletBinding()]
param(
    [ValidateSet(32,48,64)][int]$Size = 48,
    [switch]$Restore,
    [switch]$CheckOnly
)
$ErrorActionPreference = 'Stop'
$schemeName = 'Naiwa'
$installRoot = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'NaiwaCursorPack'
$backupPath = Join-Path $installRoot 'previous-cursors.json'

try {
    if (-not ('Naiwa.Native' -as [type])) {
        Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
namespace Naiwa {
    public static class Native {
        [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        public static extern IntPtr LoadImageW(IntPtr h, string path, uint type, int cx, int cy, uint flags);
        [DllImport("user32.dll", SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool DestroyCursor(IntPtr handle);
        [DllImport("user32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static extern bool SystemParametersInfoW(uint action, uint parameter, IntPtr value, uint flags);
        public static int ReloadCursors() {
            // Registry settings are already saved. Only reload; profile-write flags can fail.
            if (SystemParametersInfoW(0x57, 0, IntPtr.Zero, 0)) return 0;
            int error = Marshal.GetLastWin32Error();
            return error == 0 ? -1 : error;
        }
    }
}
'@
    }

    function Refresh-Cursors {
        $nativeError = [Naiwa.Native]::ReloadCursors()
        if ($nativeError -ne 0) {
            throw "Windows could not refresh cursors. Error: $nativeError"
        }
    }

    function Get-ValueSnapshot($Key, [string]$Name) {
        $exists = $Key.GetValueNames() -contains $Name
        if ($exists) {
            return [pscustomobject]@{
                Name=$Name; Exists=$true; Kind=$Key.GetValueKind($Name).ToString()
                Value=$Key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            }
        }
        return [pscustomobject]@{ Name=$Name; Exists=$false; Kind='String'; Value=$null }
    }

    function Set-ValueSnapshot($Key, $Entry) {
        if (-not $Entry.Exists) { $Key.DeleteValue([string]$Entry.Name,$false); return }
        $kind = [Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind],[string]$Entry.Kind)
        $value = $Entry.Value
        switch ([string]$Entry.Kind) {
            'DWord' { $value = [int]$Entry.Value }
            'QWord' { $value = [long]$Entry.Value }
            'Binary' { $value = [byte[]]$Entry.Value }
            'MultiString' { $value = [string[]]$Entry.Value }
            default { $value = [string]$Entry.Value }
        }
        $Key.SetValue([string]$Entry.Name,$value,$kind)
    }

    function Restore-Snapshot($Snapshot) {
        $cursorKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Control Panel\Cursors')
        $schemeKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Control Panel\Cursors\Schemes')
        try {
            foreach ($entry in $Snapshot.Values) { Set-ValueSnapshot $cursorKey $entry }
            Set-ValueSnapshot $schemeKey $Snapshot.Scheme
        } finally { $cursorKey.Dispose(); $schemeKey.Dispose() }
        Refresh-Cursors
    }

    if ($Restore) {
        if ($CheckOnly) { throw 'Restore and CheckOnly cannot be combined.' }
        if (-not (Test-Path -LiteralPath $backupPath)) {
            Write-Host '没有待恢复的备份。若需系统默认指针：Win+R，输入 main.cpl，在“指针”页选择 Windows 默认方案。'
            exit 0
        }
        $backup = Get-Content -LiteralPath $backupPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($backup.Format -ne 'NaiwaCursorBackup-v1') { throw 'Unrecognized backup format.' }
        Restore-Snapshot $backup
        $historyPath = Join-Path $installRoot ('restored-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N') + '.json')
        Move-Item -LiteralPath $backupPath -Destination $historyPath
        Write-Host '已恢复安装奶蛙之前的指针方案。' -ForegroundColor Green
        exit 0
    }

    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($manifest.roles.Count -ne 17) { throw 'This package must contain 17 cursor roles.' }
    $source = Join-Path $PSScriptRoot ('cursors\' + $Size)
    foreach ($role in $manifest.roles) {
        $file = Join-Path $source $role.file
        if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw "Missing cursor: $file" }
        $handle = [Naiwa.Native]::LoadImageW([IntPtr]::Zero,$file,2,$Size,$Size,0x10)
        if ($handle -eq [IntPtr]::Zero) { throw "Windows could not load cursor: $file" }
        [void][Naiwa.Native]::DestroyCursor($handle)
    }
    if ($CheckOnly) {
        Write-Host "OK: Windows loaded all 17 cursors at ${Size}px. No settings or installed files changed."
        exit 0
    }

    # Assets live at a permanent per-user path, so the downloaded ZIP can be removed later.
    [void][IO.Directory]::CreateDirectory($installRoot)
    $assetDir = Join-Path $installRoot ('assets\' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N'))
    [void][IO.Directory]::CreateDirectory($assetDir)
    foreach ($role in $manifest.roles) {
        Copy-Item -LiteralPath (Join-Path $source $role.file) -Destination (Join-Path $assetDir $role.file)
    }
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot 'Setup.ps1') -Destination (Join-Path $installRoot 'Setup.ps1') -Force
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot '恢复之前指针.cmd') -Destination (Join-Path $installRoot '恢复之前指针.cmd') -Force

    $cursorKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Control Panel\Cursors')
    $schemeKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Control Panel\Cursors\Schemes')
    try {
        $changedNames = @($manifest.roles | ForEach-Object { [string]$_.registry }) + @('','Scheme Source','CursorBaseSize')
        # Preserve the first pre-install state even if the user later changes Naiwa size.
        if (-not (Test-Path -LiteralPath $backupPath)) {
            $backup = [pscustomobject]@{
                Format='NaiwaCursorBackup-v1'
                Created=[DateTime]::Now.ToString('o')
                Values=@($changedNames | ForEach-Object { Get-ValueSnapshot $cursorKey $_ })
                Scheme=(Get-ValueSnapshot $schemeKey $schemeName)
            }
            $backup | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath $backupPath -Encoding UTF8
        } else {
            $backup = Get-Content -LiteralPath $backupPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ($backup.Format -ne 'NaiwaCursorBackup-v1') { throw 'Unrecognized backup format; nothing applied.' }
        }
        # Snapshot current values for rollback if this installation itself fails.
        $transaction = [pscustomobject]@{
            Values=@($changedNames | ForEach-Object { Get-ValueSnapshot $cursorKey $_ })
            Scheme=(Get-ValueSnapshot $schemeKey $schemeName)
        }
        try {
            $paths = @()
            foreach ($role in $manifest.roles) {
                $path = Join-Path $assetDir $role.file
                $cursorKey.SetValue([string]$role.registry,$path,[Microsoft.Win32.RegistryValueKind]::String)
                $paths += $path
            }
            $schemeKey.SetValue($schemeName,($paths -join ','),[Microsoft.Win32.RegistryValueKind]::String)
            $cursorKey.SetValue('',$schemeName,[Microsoft.Win32.RegistryValueKind]::String)
            $cursorKey.SetValue('Scheme Source',1,[Microsoft.Win32.RegistryValueKind]::DWord)
            $cursorKey.SetValue('CursorBaseSize',$Size,[Microsoft.Win32.RegistryValueKind]::DWord)
            Refresh-Cursors
        } catch {
            foreach ($entry in $transaction.Values) { Set-ValueSnapshot $cursorKey $entry }
            Set-ValueSnapshot $schemeKey $transaction.Scheme
            try { Refresh-Cursors } catch { }
            throw
        }
    } finally { $cursorKey.Dispose(); $schemeKey.Dispose() }
    Write-Host "奶蛙全套指针已安装并应用：17 种状态，${Size}px。" -ForegroundColor Green
    Write-Host '不需要管理员权限。鼠标方案名称：Naiwa。'
    Write-Host "恢复入口：$(Join-Path $installRoot '恢复之前指针.cmd')"
    exit 0
} catch {
    Write-Host ('操作未完成：' + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
